package infra.issueloader;

public interface IIssueLoader {
	void loadIssues();
}
